sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ.controller.App", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.ZCUST_PROJ.view.App
		 */
		onInit: function () {
			var cutoverData = [{
				CustId: "69950",
				Customer: "Amazon US",
			}, {
				CustId: "69951",
				Customer: "Walmart",
			}];
			var CutoverTableModel = new sap.ui.model.json.JSONModel(cutoverData);
			//	this.getView().byId("listId").setModel(oModel1,"MainModel");listIdSPAU
			this.getView().setModel(CutoverTableModel, "UserIssueListModel");

			var cutoverData1 = [{
				CondType: "MSPRP",
				SalesOrg: "Google LLC",
				SoldToParty: "Amazon US",
				SKUType: "Pristine",
				Amount: "499",
				Status: "Pending Approval",
				Per: "1",
				Unit: "EA",
				ValidFrom: "01.01.2020",
				ValidTo: "31.12.2020",
			}, {
				CondType: "Channel Margin",
				SalesOrg: "Google LLC",
				SoldToParty: "Amazon US",
				SKUType: "Pristine",
				Amount: "5.18",
				Status: "Pending Approval",
				Per: "1",
				Unit: "EA",
				ValidFrom: "01.01.2020",
				ValidTo: "31.12.2020",
			},
			{
				CondType: "Other Allowance 1",
				SalesOrg: "Google LLC",
				SoldToParty: "Amazon US",
				SKUType: "Pristine",
				Amount: "2",
				Status: "Pending Approval",
				Per: "1",
				Unit: "EA",
				ValidFrom: "01.01.2020",
				ValidTo: "31.12.2020",
			}];
			var CutoverTableModel1 = new sap.ui.model.json.JSONModel(cutoverData1);
			this.getView().setModel(CutoverTableModel1, "TableModel");
		},
		
	

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf test.ZCUST_PROJ.view.App
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf test.ZCUST_PROJ.view.App
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf test.ZCUST_PROJ.view.App
		 */
		//	onExit: function() {
		//
		//	}

	});

});