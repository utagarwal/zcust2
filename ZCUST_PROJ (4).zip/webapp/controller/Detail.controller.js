sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ.controller.Detail", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		onInit: function () {

			var payload = [];
			var columnData = [{
				Field1: "Cond Type",
				Field2: "Sales org",
				Field3: "Sold to party",
				Field4: "SKU Type"
			}];

			var tableData = [{
				Cond_Type: "MSPRP",
				Sales_org: "Google LLC",
				SoldToParty: "Amazon US",
				SKU_Type: "Pristine",

			}, {
				Cond_Type: "MSPRP",
				Sales_org: "",
				SoldToParty: "Amazon US",
				SKU_Type: "Pristine"
			}];

			var columnData1 = [{
				Field1: "Sales org",
				Field2: "SKU Type",
				Field3: "Status",
				Field4: "Sold to party"
			}];

			var tableData1 = [{
				Sales_org: "Google LLC",
				SKU_Type: "Pristine",
				Status: "Approved",
				SoldToParty: "Amazon US"
			}, {
				Sales_org: "Google LLC",
				SKU_Type: "Pristine",
				Status: "Rejected",
				SoldToParty: "Walmart"
			}];

			var condTableName1 = "902";
			var condTableName2 = "910";

			var dataSet1 = {};
			dataSet1.condTableName1 = condTableName1;
			dataSet1.columnData = columnData;
			dataSet1.tableData = tableData;

			var dataSet2 = {};
			dataSet2.condTableName1 = condTableName2;
			dataSet2.columnData = columnData1;
			dataSet2.tableData = tableData1;

			var payload = [dataSet1, dataSet2];

			for (var k = 0; k < payload.length; k++) {
				var table1 = new sap.m.Table({
					id: "table_" + k,
					growing: true,
					alternateRowColors: true
				}).addStyleClass("sapUiLargeMarginTop");

				var ModelDynValId = "Model" + k;
				var ModelDynVal = "Model" + k;

				ModelDynVal = new JSONModel();
				ModelDynVal.setData(payload[k].tableData);
				table1.setModel(ModelDynVal, ModelDynValId);

				var arrayCol = [];
				var p = payload[k].columnData[0];
				for (var key in p) {
					if (p.hasOwnProperty(key)) {
						arrayCol.push(p[key]);
					}
				}

				var tableDataRow = [];
				var p1 = payload[k].tableData[0];
				for (var key1 in p1) {
					if (p.hasOwnProperty(key)) {
						tableDataRow.push(key1);
					}
				}

				for (var i = 0; i < arrayCol.length; i++) {
					var oColumn = new sap.m.Column("col" + i + k, {
						header: new sap.m.Label({
							text: arrayCol[i]
						})
					});
					table1.addColumn(oColumn);
				}

				var bindModel = ModelDynValId + ">/";
				var bindModelTable = ModelDynValId + ">";
				table1.bindAggregation("items", bindModel, new sap.m.ColumnListItem({
					cells: [
						new sap.m.Label({
							text: "{" + bindModelTable + tableDataRow[0] + "}"
						}),
						new sap.m.Text({
							text: "{" + bindModelTable + tableDataRow[1] + "}"
						}),
						new sap.m.Label({
							text: "{" + bindModelTable + tableDataRow[2] + "}"
						}),
						new sap.m.Text({
							text: "{" + bindModelTable + tableDataRow[3] + "}"
						})
						/*	new sap.m.Text({
								text: "{DataModel>SoldToParty}"
							}),
							new sap.m.Text({
								text: "{DataModel>SKU_Type}"
							}),
								new sap.m.Text({
								text: "{DataModel>Status}"
							})*/
					]
				}));

				table1.setHeaderText(payload[k].condTableName1);
				table1.setMode("MultiSelect");

				this.getView().byId("TableBox").addItem(table1);

			}

		},
		
	

		selectAllitems: function () {
			this.getView().byId("idHUTable").selectAll();
			this.getView().byId("idHUTable11A").selectAll();
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf test.ZCUST_PROJ.view.Detail
		 */
		//	onExit: function() {
		//
		//	}

	});

});