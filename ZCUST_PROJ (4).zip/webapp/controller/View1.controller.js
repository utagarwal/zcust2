sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/Sorter',
	'sap/ui/model/json/JSONModel',
	'sap/m/Menu',
	'sap/m/MenuItem'
], function (Controller, Filter, Sorter, JSONModel, Menu, MenuItem) {
	"use strict";

	return Controller.extend("test.ZCUST_PROJ.controller.View1", {
		onInit: function () {
			this._mViewSettingsDialogs = {};
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			var oFilter = this.getView().byId("Filterbar");


			oFilter.addEventDelegate({
				"onAfterRendering": function (oEvent) {

					var oButton = oEvent.srcControl._oSearchButton;
					oButton.setText("Execute");
				}
			});

			var cutoverData = [{
				SeqNo: "1",
				CustId: "178908",
				Customer: "Walmart",
				Product: "Pixel 4a"
			}, {
				SeqNo: "2",
				CustId: "178909",
				Customer: "Amazon US",
				Product: "PixelBook"
			}];
			var CutoverTableModel = new sap.ui.model.json.JSONModel(cutoverData);
			//	this.getView().byId("listId").setModel(oModel1,"MainModel");listIdSPAU
			this.getView().setModel(CutoverTableModel, "CutoverTableModel");

		},
		
			onExecute: function(evt){
			var ty = "!23";
		},

		onpress: function () {
			this._oRouter.navTo("SplitAppView");
		},
		createViewSettingsDialog: function (sDialogFragmentName) {
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];

			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

			}
			return oDialog;
		},

		handleSortButtonPressed: function () {
			this.createViewSettingsDialog("test.ZCUST_PROJ.view.SortDialog").open();
		},

		handleFilterButtonPressed: function () {
			this.createViewSettingsDialog("test.ZCUST_PROJ.view.FilterDialog").open();
		},

		handleSortDialogConfirm: function (oEvent) {
			var oTable = this.getView().byId("idHUTable3"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];

			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));

			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},

		handleFilterDialogConfirm: function (oEvent) {
			var oTable = this.getView().byId("idHUTable3"),
				mParams = oEvent.getParameters(),
				oBinding = oTable.getBinding("items"),
				aFilters = [];

			mParams.filterItems.forEach(function (oItem) {
				var aSplit = oItem.getKey(),
					sPath = oItem.getParent().getKey(),
					sOperator = sap.ui.model.FilterOperator.Contains,
					sValue1 = aSplit,

					oFilter = new Filter(sPath, sOperator, sValue1);
				aFilters.push(oFilter);
			});

			// apply filter settings
			oBinding.filter(aFilters);

			// update filter bar
		},

		onToggleContextMenu: function (oEvent) {
			var oToggleButton = oEvent.getSource();
			if (oEvent.getParameter("pressed")) {
				oToggleButton.setTooltip("Disable Custom Context Menu");
				this.getView().byId("idHUTable").setContextMenu(new Menu({
					items: [
						new MenuItem({
							text: "{Name}"
						}),
						new MenuItem({
							text: "{ProductId}"
						})
					]
				}));
			} else {
				oToggleButton.setTooltip("Enable Custom Context Menu");
				this.getView().byId("idHUTable3").destroyContextMenu();
			}
		}

	});
});