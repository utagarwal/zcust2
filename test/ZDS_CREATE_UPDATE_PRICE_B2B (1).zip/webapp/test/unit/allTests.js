sap.ui.define([
	"ZDS_CREATE_UPDATE_PRICE/test/unit/controller/View1.controller"
], function () {
	"use strict";
});