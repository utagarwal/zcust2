sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter"
], function (Controller, JSONModel, Filter) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE.controller.PriceApproval", {

		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("PriceApproval").attachPatternMatched(this.onRouteMatched, this);
			this.rescrModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		// This method is called when the user presses GO button at the filter bar
		colExtendedName: function (colData) {
			this.rescrModel = this.getView().getModel("i18n").getResourceBundle();
			for (var b = 0; b < colData.length; b++) {
				if (colData[b] === "ConditionRecord") {
					colData[b] = this.rescrModel.getText("ConditionRecord");
				} else if (colData[b] === "ConditionType") {
					colData[b] = this.rescrModel.getText("ConditionType");
				} else if (colData[b] === "CountryKey") {
					colData[b] = this.rescrModel.getText("CountryKey");
				} else if (colData[b] === "CustomerPriceGroup") {
					colData[b] = this.rescrModel.getText("CustomerPriceGroup");
				} else if (colData[b] === "DistributionChannel") {
					colData[b] = this.rescrModel.getText("DistributionChannel");
				} else if (colData[b] === "DocumentCurrency") {
					colData[b] = this.rescrModel.getText("DocumentCurrency");
				} else if (colData[b] === "MaterialGroup3") {
					colData[b] = this.rescrModel.getText("MaterialGroup");
				} else if (colData[b] === "MaterialNumber") {
					colData[b] = this.rescrModel.getText("MaterialNumber");
				} else if (colData[b] === "ProcessStatus") {
					colData[b] = this.rescrModel.getText("ProcessStatus");
				} else if (colData[b] === "ProfitCenter") {
					colData[b] = this.rescrModel.getText("ProfitCenter");
				} else if (colData[b] === "ReleaseStatus") {
					colData[b] = this.rescrModel.getText("ReleaseStatus");
				} else if (colData[b] === "SalesOrganization") {
					colData[b] = this.rescrModel.getText("SalesOrganzation");
				} else if (colData[b] === "SoldToParty") {
					colData[b] = this.rescrModel.getText("SoldToParty");
				} else if (colData[b] === "UserIndicator") {
					colData[b] = this.rescrModel.getText("UserIndicator");
				} else if (colData[b] === "ValidFrom") {
					colData[b] = this.rescrModel.getText("ValidFrom");
				} else if (colData[b] === "ValidTo") {
					colData[b] = this.rescrModel.getText("ValidTo");
				} else if (colData[b] === "VendorAccountNumber") {
					colData[b] = this.rescrModel.getText("VendorAccountNumber");
				} else if (colData[b] === "ProductKey") {
					colData[b] = this.rescrModel.getText("ProductKey");
				} else if (colData[b] === "NewValidFrom") {
					colData[b] = this.rescrModel.getText("NewValidFrom");
				} else if (colData[b] === "NewValidTo") {
					colData[b] = this.rescrModel.getText("NewValidTo");
				} else if (colData[b] === "Customer") {
					colData[b] = this.rescrModel.getText("Customer");
				} else if (colData[b] === "CustomerSpecificAmount") {
					colData[b] = this.rescrModel.getText("CustomerSpecificAmount");
				} else if (colData[b] === "MaterialGroupDesc") {
					colData[b] = this.rescrModel.getText("MaterialGroupDesc");
				} else if (colData[b] === "DistributionChannelDesc") {
					colData[b] = this.rescrModel.getText("DistributionChannelDesc");
				} else if (colData[b] === "StatusDesc") {
					colData[b] = this.rescrModel.getText("StatusDesc");
				} else if (colData[b] === "CustomerName") {
					colData[b] = this.rescrModel.getText("CustomerName");
				} else if (colData[b] === "ConditionTypeDescription") {
					colData[b] = this.rescrModel.getText("ConditionTypeDescription");
				} else if (colData[b] === "IntentOfUseDesc") {
					colData[b] = this.rescrModel.getText("IntentOfUseDesc");
				} else if (colData[b] === "ShipToCountryDesc") {
					colData[b] = this.rescrModel.getText("ShipToCountryDesc");
				} else if (colData[b] === "Unit") {
					colData[b] = this.rescrModel.getText("Currency");
				} else if (colData[b] === "PricingUnit") {
					colData[b] = this.rescrModel.getText("PricingUnit");
				} else if (colData[b] === "ContractID") {
					colData[b] = this.rescrModel.getText("ContractID");
				}
			}
			return colData;
		},

		convertGwDatetoUI: function (convertDate) {
			if (convertDate) {
				var date = convertDate.substring(4, 6) + "." + convertDate.substring(6, 8) + "." + convertDate.substring(0, 4);
				return date;
			}
		},
		
			convertUIDatetoGW: function (convertDate) {
			if (convertDate) {
				var date = convertDate.substring(6, 10) + convertDate.substring(0, 2) + convertDate.substring(3, 5);
				return date;
			}
		},

		onConditionTableDynamicBinding: function (TableData, ColData) {
			this.getView().byId("TableBox").destroyItems();
			for (var n = 0; n < TableData.results.length; n++) {

				var validToDate = TableData.results[n].ValidTo;
				var validFromDate = TableData.results[n].ValidFrom;
				var newValidToDate = TableData.results[n].NewValidTo;
				var newValidFromDate = TableData.results[n].NewValidFrom;
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MM.dd.yyyy"
				});
				var dateObjValidFrom = convertGwDatetoUI(validFromDate);
				var dateObjValidTo = convertGwDatetoUI(validToDate);
				var dateObjNewValidFrom = convertGwDatetoUI(newValidFromDate);
				var dateObjNewValidTo = convertGwDatetoUI(newValidToDate);
				TableData.results[n].ValidTo = dateObjValidTo;
				TableData.results[n].ValidFrom = dateObjValidFrom;
				TableData.results[n].NewValidTo = dateObjNewValidTo;
				TableData.results[n].NewValidFrom = dateObjNewValidFrom;
				if (this.getView().byId("createCustRecord").getText() === this.rescrModel.getText("Confirm")) {
					TableData.results[n].ValidTo = dateObjNewValidTo;
					TableData.results[n].ValidFrom = dateObjNewValidFrom;
					TableData.results[n].NewValidTo = dateObjValidTo;
					TableData.results[n].NewValidFrom = dateObjValidFrom;
				}
				if (TableData.results[n].Unit !== "%") {
					var val = parseFloat(TableData.results[n].CustomerSpecificAmount);
					TableData.results[n].CustomerSpecificAmount = val.toFixed(2);
				}
			}
			var TableDataResult = TableData.results.reduce(function (r, a) {
				r[a.TableName] = r[a.TableName] || [];
				r[a.TableName].push(a);
				return r;
			}, Object.create(null));

			var arrayUniqueData = [];
			var uniqueDataSplit = TableDataResult;
			for (var key in uniqueDataSplit) {
				for (var t = 0; t < ColData.results.length; t++) {
					if (key === ColData.results[t].TableName) {
						var allData = {};
						allData.TableName = key;
						allData.TableDescription = ColData.results[t].TableDescription;
						allData.DataTable = uniqueDataSplit[key];
						allData.ColData = ColData.results[t];
						arrayUniqueData.push(allData);
					}
				}
			}

			var uniqueTableColArray = arrayUniqueData;
			for (var k = 0; k < uniqueTableColArray.length; k++) {
				var table1 = new sap.m.Table({
					id: "table_" + k,
					growing: true,
					alternateRowColors: true
				}).addStyleClass("sapUiLargeMarginTop");

				var ModelDynValId = "Model" + k;
				var ModelDynVal = "Model" + k;

				var tableDataCol = [];
				var p1 = uniqueTableColArray[k].ColData;
				Object.keys(p1).sort().reduce(function (result, key1) {
					if ((p1[key1] === true && key1 !== "CustomerSpecificAmount" && key1 !== "NewValidTo" && key1 !== "NewValidFrom" && key1 !==
							"ContractId" && key1 !== "Amount" && key1 !== "PricingUnit" && key1 !== "Uom" && key1 !== "ValidFrom" && key1 !== "ValidTo")) {
						tableDataCol.push(key1);
					}
				}, {});
				tableDataCol.push("Amount");
				tableDataCol.push("Uom");
				tableDataCol.push("PricingUnit");
				tableDataCol.push("ValidFrom");
				tableDataCol.push("ValidTo");
				if (this.getView().byId("createCustRecord").getText() !== this.rescrModel.getText("Confirm")) {
					tableDataCol.push("CustomerSpecificAmount");
					tableDataCol.push("NewValidFrom");
					tableDataCol.push("NewValidTo");
					tableDataCol.push("ContractID");
				}
				ModelDynVal = new JSONModel();
				ModelDynVal.setData(uniqueTableColArray[k].DataTable);
				table1.setModel(ModelDynVal, ModelDynValId);

				var bindModel = ModelDynValId + ">/";
				var bindModelTable = ModelDynValId + ">";

				var cols = new sap.m.ColumnListItem({
					vAlign: "Middle"
				});
				var tableDataRow = tableDataCol;
				for (var l = 0; l < tableDataRow.length; l++) {
					if (tableDataRow[l] === "CustomerSpecificAmount") {
						var input = new sap.m.Input({
							type: "Number",
							value: "{" + bindModelTable + "CustomerSpecificAmount}",
							liveChange: function (oEvent) {
								var rowData = oEvent.getSource().mBindingInfos.value.binding.getContext().getObject();
								if (rowData.Unit === "%") {
									var t = oEvent.getSource().getValue();
									var t1 = (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 4)) : t;
									oEvent.getSource().setValue(t1);
								} else {
									var t = oEvent.getSource().getValue();
									var t1 = (t.indexOf(".") >= 0) ? (t.substr(0, t.indexOf(".")) + t.substr(t.indexOf("."), 3)) : t;
									oEvent.getSource().setValue(t1);
								}
							}
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "NewValidTo") {
						var input = new sap.m.DatePicker({
							value: "{" + bindModelTable + "NewValidTo}",
							change: function (oEvent) {
								var rowData = oEvent.getSource().mBindingInfos.value.binding.getContext().getObject();
								var cells = oEvent.getSource().getParent().getCells();
								var table = oEvent.getSource().getParent().getParent();
								var tableColumns = table.getColumns();
								var newValidToDate = new Date(rowData.NewValidTo);
								var newValidFromDate = new Date(rowData.NewValidFrom);
								var validToDate = new Date(rowData.ValidTo);
								var errFlag = false;
								var errMsg;
								if (newValidToDate.toJSON() < newValidFromDate.toJSON()) {
									errFlag = true;
									errMsg = this.rescrModel.getText("DateMsg1"),
								} else if (newValidToDate.toJSON() > validToDate.toJSON()) {
									errFlag = true;
									errMsg = this.rescrModel.getText("DateMsg2"),
								}

								for (var j = 0; j < tableColumns.length; j++) {
									if (tableColumns[j].getHeader().getText() === this.rescrModel.getText("NewValidTo"), ) {
										if (errFlag) {
											cells[j].setValueState(sap.ui.core.ValueState.Error);
											sap.m.MessageToast.show(errMsg);
										} else {
											cells[j].setValueState("None");
										}
									}
								}

							},
							displayFormat: "MM.dd.yyyy",
							valueFormat: "MM.dd.yyyy"
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "NewValidFrom") {
						var input = new sap.m.DatePicker({
							value: "{" + bindModelTable + "NewValidFrom}",
							change: function (oEvent) {
								var rowData = oEvent.getSource().mBindingInfos.value.binding.getContext().getObject();
								var cells = oEvent.getSource().getParent().getCells();
								var table = oEvent.getSource().getParent().getParent();
								var tableColumns = table.getColumns();
								var newValidToDate = new Date(rowData.NewValidTo);
								var newValidFromDate = new Date(rowData.NewValidFrom);
								var validFromDate = new Date(rowData.ValidFrom);
								var errFlag = false;
								var errMsg;
								if (newValidFromDate.toJSON() > newValidToDate.toJSON()) {
									errFlag = true;
									errMsg = this.rescrModel.getText("DateMsg3");
								} else if (newValidFromDate.toJSON() < validFromDate.toJSON()) {
									errFlag = true;
									errMsg = this.rescrModel.getText("DateMsg4");
								}

								for (var j = 0; j < tableColumns.length; j++) {
									if (tableColumns[j].getHeader().getText() === this.rescrModel.getText("NewValidFrom")) {
										if (errFlag) {
											cells[j].setValueState("Error");
											sap.m.MessageToast.show(errMsg);
										} else {
											cells[j].setValueState("None");
										}
									}
								}

							},

							displayFormat: "MM.dd.yyyy",
							valueFormat: "MM.dd.yyyy"
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					} else if (tableDataRow[l] === "ContractID") {
						var input = new sap.m.Input({
							value: "{" + bindModelTable + "ContractID}",
							liveChange: function (oEvent) {
								oEvent.getSource().setValueState("None");
							}
						}).addStyleClass("marginTableBtn");
						cols.addCell(input);
					}
					else if (tableDataRow[l] === "Unit" || tableDataRow[l] === "Amount" ||  tableDataRow[l] === "ConditionType") {
						var label = new sap.m.Text({
							text: "{" + bindModelTable + tableDataRow[l] + "}",
							wrapping: true
						}).addStyleClass("boldCSS");
						cols.addCell(input);
					}
					else {
						var label = new sap.m.Text({
							text: "{" + bindModelTable + tableDataRow[l] + "}",
							wrapping: true
						});

						cols.addCell(label);
					}
				}
				tableDataCol = this.colExtendedName(tableDataCol);
				for (var i = 0; i < tableDataCol.length; i++) {
					if (tableDataCol[i] === this.rescrModel.getText("NewValidFrom") || tableDataCol[i] === this.rescrModel.getText("NewValidTo") ||
						tableDataCol[i] === this.rescrModel.getText("ContractID")) {
						var oColumn = new sap.m.Column("col" + i + k, {
							width: "9rem",
							header: new sap.m.Text({
								text: tableDataCol[i],
								wrapping: true
							})
						});
					} else if (tableDataCol[i] === this.rescrModel.getText("Amount") || tableDataCol[i] === this.rescrModel.getText("Currency") ||
						tableDataCol[i] === this.rescrModel.getText("PricingUnit") || tableDataCol[i] === this.rescrModel.getText("Uom")) {
						var oColumn = new sap.m.Column("col" + i + k, {
							width: "5rem",
							header: new sap.m.Text({
								text: tableDataCol[i],
								wrapping: true
							})
						});
					} else {
						var oColumn = new sap.m.Column("col" + i + k, {
							width: "7rem",
							header: new sap.m.Text({
								text: tableDataCol[i],
								wrapping: true
							})
						});
					}
					table1.addColumn(oColumn);
				}
				table1.bindAggregation("items", bindModel, cols);
				var headerText = uniqueTableColArray[k].TableName + " - " + uniqueTableColArray[k].TableDescription;
				table1.setHeaderText(headerText);
				table1.setGrowingThreshold(200);
				table1.setGrowing(true);
				table1.setGrowingScrollToLoad(true);
				table1.setMode("MultiSelect");
				this.getView().byId("TableBox").addItem(table1);
			}
		},

		onApvRejPress: function (evt) {
			if (this.getView().byId("createCustRecord").getText() !== this.rescrModel.getText("Confirm")) {
				this.btnAction = evt.getSource().getText();
				var btnText = this.btnAction;
				var tables = this.getView().byId("TableBox").getItems();
				var dataPresent = false;
				var allDataSelected = true;
				for (var i = 0; i < tables.length; i++) {
					var tableSelectedData = tables[i].getSelectedContexts();
					if (tableSelectedData.length > 0) {
						dataPresent = true;
						var tableColumns = tables[i].getColumns();
						for (var j = 0; j < tableColumns.length; j++) {
							if (tableColumns[j].getHeader().getText() === this.rescrModel.getText("NewValidTo") || tableColumns[j].getHeader().getText() ===
								this.rescrModel.getText("NewValidFrom")) {
								for (var k = 0; k < tables[i].getSelectedItems().length; k++) {
									if (tables[i].getSelectedItems()[k].getCells()[j].getValueState() === "Error") {
										sap.m.MessageToast.show(this.rescrModel.getText("ErrMsgValidate"));
										return false;
									}
								}
							}
						}

					} else {
						allDataSelected = false;
					}
					if (tableSelectedData.length !== tables[i].getItems().length) {
						allDataSelected = false;
					}
				}
				for (var i = 0; i < tables.length; i++) {
					var tableSelectedData = this.getView().byId("TableBox").getItems()[i].getSelectedContexts();
					if (tableSelectedData.length > 0) {
						dataPresent = true;
					} else {
						allDataSelected = false;
					}
					if (tableSelectedData.length !== tables[i].getItems().length) {
						allDataSelected = false;
					}
				}
				if (!dataPresent) {
					sap.m.MessageToast.show(this.rescrModel.getText("NoItemSelected"));
					return false;
				}
				if (!this.oApvRejConfirm) {
					this.oApvRejConfirm = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ApproveRejectConfirmDialog", this);
					this.getView().addDependent(this.oApvRejConfirm);
				}
				this.oApvRejConfirm.open();
			} else {
				this.onApproveRejBtnPress();
			}
		},

		onClose: function () {
			if (!this.oApvRejConfirm) {
				this.oApvRejConfirm = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ApproveRejectConfirmDialog", this);
			}
			this.oApvRejConfirm.close();
		},

		onRouteMatched: function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			this.getView().byId("createCustRecord").setText(this.rescrModel.getText("CreateCustomerRecord"));
			this.customer = oArgs.Customer;
			this.productVal = oArgs.Material;
			this.contractVal = oArgs.Contract;
			if (oArgs.Contract ===  this.rescrModel.getText("NoContractId")) {
				this.contractVal = "";
			}
			this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
		},

		onConfirmScreenSrvCall: function (data) {
			this.getView().byId("createCustRecord").setText(this.rescrModel.getText("Confirm"));
			this.getView().byId("priceApprovalPageID").setTitle(this.rescrModel.getText("ConfirmCreationCustomerSpecificRecordsMsg"));
			this.getView().byId("deleteCustRecord").setVisible(false);
			this.getView().byId("cancelCustRecord").setVisible(true);
			var oModel = this.getOwnerComponent().getModel();

			var that = this;
			var conditionTableData = {};
			conditionTableData.results = data;
			var oServiceColModel = that.getOwnerComponent().getModel();
			oServiceColModel.read("/ConditionFieldsIdentification", {
				success: function (oData, oResponse) {
					if (data.length !== 0) {
						var ContractListModel = new sap.ui.model.json.JSONModel(data);
						that.getView().setModel(ContractListModel, "ContractListModel");
						that.onConditionTableDynamicBinding(conditionTableData, oData);
						that.disableTableSelection();
					}
				},
				error: function (oError) {

				}
			});

		},
		onCancelBtnPress: function () {
			this.onConditionTableSrvCall();
		},
		onConditionTableSrvCall: function (Customer, Material, ContractId) {
			this.getView().byId("createCustRecord").setText(this.rescrModel.getText("CreateCustomerRecord"));
			this.getView().byId("priceApprovalPageID").setTitle(this.rescrModel.getText("CreateChangePrice"));
			this.getView().byId("deleteCustRecord").setVisible(true);
			this.getView().byId("cancelCustRecord").setVisible(false);

			var filtersData = this.getView().getModel("FilterModel").getData().filterDataObj;
			var aFilters = this.getView().getModel("FilterModel").getData().aFilters;
			var oModel = this.getOwnerComponent().getModel();
			/*	for (var q = 0; q < aFilters["aFilters"].length; q++) {
					if (aFilters["aFilters"][q].sPath === "ValidOn") {
						var ValidOnDate = aFilters["aFilters"][q].oValue1;
						var convValidOnDate = ValidOnDate.substring(4, 6) + "." + ValidOnDate.substring(6, 8) + "." + ValidOnDate.substring(0, 4);
					} else if (aFilters["aFilters"][q].sPath === "ProductKey") {
						this.getView().byId("ProductDisplayID").setText(aFilters["aFilters"][q].oValue1);
					} else if (aFilters["aFilters"][q].sPath === "Customer") {
						this.getView().byId("CustomerDisplayID").setText(aFilters["aFilters"][q].oValue1);
					} else if (aFilters["aFilters"][q].sPath === "Scenario") {
						this.getView().byId("ActionDisplayID").setText(aFilters["aFilters"][q].oValue1);
					}
				}*/

			var ValidOnDate = filtersData.validOn;
		//	var convValidOnDate = ValidOnDate.substring(4, 6) + "." + ValidOnDate.substring(6, 8) + "." + ValidOnDate.substring(0, 4);
			var convValidOnDate = convertGwDatetoUI(ValidOnDate);
			this.getView().byId("ProductDisplayID").setText(filtersData.productKey);
			this.getView().byId("CustomerDisplayID").setText(filtersData.customer);
			this.getView().byId("ActionDisplayID").setText(filtersData.action);

			this.getView().byId("ValidOnDisplayID").setText(convValidOnDate);
			var view = this.getView();
				var that = this;
			oModel.attachRequestSent(function () {
				if (!view._oBusyDialog) {
					view._oBusyDialog = new sap.m.BusyDialog({
						title: that.rescrModel.getText("PleaseWaitMsg")
					});
					view.addDependent(view._oBusyDialog);
				}
				view._oBusyDialog.open();
			});
			oModel.fireRequestSent();
		
			oModel.read("/PriceRecords", {
				filters: aFilters,
				success: function (oData, oResponse) {
					var conditionTableData = oData;
					var oServiceColModel = that.getOwnerComponent().getModel();
					var that1 = that;
					oServiceColModel.read("/ConditionFieldsIdentification", {
						success: function (data, oResponse) {
							if (oData.results.length !== 0) {
								var ContractListModel = new sap.ui.model.json.JSONModel(oData.results);
								that1.getView().setModel(ContractListModel, "ContractListModel");
								that1.onConditionTableDynamicBinding(conditionTableData, data);
							} else {
								sap.m.MessageToast.show(that1.rescrModel.getText("NoRecordsFound"));
							}
							if (view._oBusyDialog) {
								view._oBusyDialog.close();
							}
						},
						error: function (oError) {
							sap.m.MessageToast.show(that1.rescrModel.getText("Error"));
						}
					});
				},
				error: function (oError) {
					sap.m.MessageToast.show(that.rescrModel.getText("Error"));
				}
			});
		},
		onApproveRejBtnPress: function () {
			this.onClose();
			var btnText = this.btnAction;
			var Action;
			var tables = this.getView().byId("TableBox").getItems();
			var tableData = [];
			var CallBapiFlag = false;
			var tableSelectedData = [];
			var actionFlag = "CREATE";
			var emailFlag = "";
			var aFilters = this.getView().getModel("FilterModel").getData();
			actionFlag = aFilters["aFilters"][0].oValue1;
			if (this.getView().byId("createCustRecord").getText() === this.rescrModel.getText("Confirm")) {
				CallBapiFlag = true;
				emailFlag = "X";
			}
			if (btnText === "Delete") {
				actionFlag = "DELETE";
			}
			for (var m = 0; m < tables.length; m++) {
				this.getView().byId("TableBox").getItems()[0].mBindingInfos.items.binding.getContexts()[0].getObject();
				if (this.getView().byId("createCustRecord").getText() === this.rescrModel.getText("Confirm")) {
					tableSelectedData = tables[m].mBindingInfos.items.binding.getContexts();
				} else {
					tableSelectedData = this.getView().byId("TableBox").getItems()[m].getSelectedContexts();
				}
				var validOnDate = this.getView().byId("ValidOnDisplayID").getText();
				if (tableSelectedData.length > 0) {
					for (var k = 0; k < tableSelectedData.length; k++) {
						var selData = tableSelectedData[k].getObject();
						var selStatusData = {};
						selStatusData.ConditionRecord = selData.ConditionRecord;
						selStatusData.TableName = selData.TableName;
						selStatusData.ProductKey = selData.ProductKey;
						selStatusData.MaterialGroup3 = selData.MaterialGroup3;
						selStatusData.ValidOn = this.convertUIDatetoGW(validOnDate);
						selStatusData.Customer = this.getView().byId("CustomerDisplayID").getText();
						selStatusData.SalesOrganization = selData.SalesOrganization;
						selStatusData.DistributionChannel = selData.DistributionChannel;
						selStatusData.ShipToCountry = selData.ShipToCountry;
						selStatusData.CallBapi = CallBapiFlag;
						selStatusData.Scenario = actionFlag;
						selStatusData.ConditionType = selData.ConditionType;
						selStatusData.ProcessStatus = selData.ProcessStatus;
						selStatusData.Unit = selData.Unit;
						selStatusData.Amount = selData.CustomerSpecificAmount;
						selStatusData.CustomerSpecificAmount = selData.CustomerSpecificAmount;
						selStatusData.PricingUnit = selData.PricingUnit;
						selStatusData.DocumentCurrency = selData.DocumentCurrency;
						selStatusData.ContractID = selData.ContractID;
						selStatusData.ValidTo = this.convertUIDatetoGW(selData.ValidTo);
						selStatusData.ValidFrom = this.convertUIDatetoGW(selData.ValidFrom);
						selStatusData.NewValidTo = this.convertUIDatetoGW(selData.NewValidTo);
						selStatusData.NewValidFrom = this.convertUIDatetoGW(selData.NewValidFrom);
						selStatusData.MaterialGroupDesc = selData.MaterialGroupDesc;
						selStatusData.DistributionChannelDesc = selData.DistributionChannelDesc;
						selStatusData.StatusDesc = selData.StatusDesc;
						selStatusData.CustomerName = selData.CustomerName;
						selStatusData.ConditionTypeDescription = selData.ConditionTypeDescription;
						selStatusData.IntentOfUseDesc = selData.IntentOfUseDesc;
						selStatusData.ShipToCountryDesc = selData.ShipToCountryDesc;
						selStatusData.EmailFlag = emailFlag;
						if (CallBapiFlag) {
							selStatusData.NewValidTo = this.convertUIDatetoGW(selData.ValidTo);
							selStatusData.NewValidFrom = this.convertUIDatetoGW(selData.ValidFrom);
							selStatusData.ValidTo = this.convertUIDatetoGW(selData.NewValidTo);
							selStatusData.ValidFrom =this.convertUIDatetoGW(selData.NewValidFrom);
						}
						tableData.push(selStatusData);
					}
				}
			}
			if (btnText === this.rescrModel.getText("Approve")) {
				Action = "/Approve_Records";
			} else {
				Action = "/Reject_Records";
			}
			var oServiceModel = this.getOwnerComponent().getModel();
			var that = this;
			//Busy Dialog
			var view = this.getView();
			oServiceModel.attachRequestSent(function () {
				if (!view._oBusyDialog) {
					view._oBusyDialog = new sap.m.BusyDialog({
						title: that.rescrModel.getText("PleaseWaitMsg")
					});
					view.addDependent(view._oBusyDialog);
				}
				view._oBusyDialog.open();
			});
			oServiceModel.attachRequestCompleted(function () {
				if (view._oBusyDialog) {
					view._oBusyDialog.close();
				}
			});
			oServiceModel.fireRequestSent();
			
			oServiceModel.setDeferredGroups(["batchcall"]);
			for (var i = 0; i < tableData.length; i++) {
				var singleentry = {};
				singleentry.properties = tableData[i];
				singleentry.changeSetId = "changeset " + i;
				this.getOwnerComponent().getModel().create("/PriceRecords", tableData[i], {
					groupId: "batchcall"
				});
			}
			oServiceModel.submitChanges({
				groupId: "batchcall", //Same as the batch group id used previously
				success: function (oData) {
					if (btnText === "Delete") {
						this.onConditionTableSrvCall();
						sap.m.MessageToast.show(this.rescrModel.getText("DeleteMsg"));
						return false;
					}
					if (this.getView().byId("createCustRecord").getText() !== this.rescrModel.getText("Confirm")) {
						var allSuccess = true;
						var conflictRecordsPresent = false;
						var conflictRecords = [];
						var conflictRecordsAllData = [];
						var errorRecords = [];
						var successRecords = [];
						var srvResponse = oData.__batchResponses[0].__changeResponses;
						for (var j = 0; j < (srvResponse.length); j++) {
							var recordData = {};
							var errorData = {};
							if (srvResponse[j].data.MessageCode === "E" && srvResponse[j]
								.data
								.Message !== "") {
								errorData.ConditionRecord = srvResponse[j].data.ConditionRecord;
								errorData.TableName = srvResponse[j].data.TableName;
								errorData.Message = srvResponse[j].data.Message;
								errorRecords.push(errorData);
								allSuccess = false;
							}
							if (srvResponse[j].data.MessageCode === "S") {
								successRecords.push(srvResponse[j].data);
							}
							if (srvResponse[j].data.MessageCode === "I") {
								conflictRecordsAllData.push(srvResponse[j].data);
								recordData.ConditionRecord = srvResponse[j].data.ConditionRecord;
								recordData.ConditionType = srvResponse[j].data.ConditionType;
								recordData.TableName = srvResponse[j].data.TableName;
								var validToDate = srvResponse[j].data.ValidTo;
								var validFromDate = srvResponse[j].data.ValidFrom;
								var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
									pattern: "MM.dd.yyyy"
								});
								recordData.ValidTo = this.convertGwDatetoUI(validToDate);
								recordData.ValidFrom =this.convertGwDatetoUI(validFromDate);
								conflictRecords.push(recordData);
								conflictRecordsPresent = true;
							}
						}
						this.successRecords = successRecords;
						var allData = [];
						allData = successRecords.concat(conflictRecordsAllData);
						this.allData = allData;
						if (allSuccess === false && errorRecords.length !== 0) {
							var ErrorMesssagesModel = new JSONModel();
							ErrorMesssagesModel.setData(errorRecords);

							if (!that.oErrorMsgsDailog) {
								that.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.Fragments.ErrorMessages", that);
								that.getView().addDependent(that.oErrorMsgsDailog);
							}
							that.oErrorMsgsDailog.open();
							that.oErrorMsgsDailog.setModel(ErrorMesssagesModel, "ErrorMesssagesModel");
						}
						if (conflictRecordsPresent === true) {
							var ConflictRecordsModel = new JSONModel();
							ConflictRecordsModel.setData(conflictRecords);

							if (!that.oConflictRecordsDailog) {
								that.oConflictRecordsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ConflictRecords", that);
								that.getView().addDependent(that.oConflictRecordsDailog);
							}
							that.oConflictRecordsDailog.open();
							that.oConflictRecordsDailog.setModel(ConflictRecordsModel, "ConflictRecordsModel");
						}
						if (btnText === that.rescrModel.getText("CreateCustomerRecord") && allSuccess && !conflictRecordsPresent && !CallBapiFlag) {
							that.getView().byId("createCustRecord").setText(that.rescrModel.getText("Confirm"));

							that.getView().byId("deleteCustRecord").setVisible(false);
							that.getView().byId("cancelCustRecord").setVisible(true);
							that.onConfirmScreenSrvCall(successRecords);
						} else if (CallBapiFlag && allSuccess && btnText === that.rescrModel.getText("Confirm")) {
							that.getView().byId("createCustRecord").setText(that.rescrModel.getText("CreateCustomerRecord"));
							that.getView().byId("cancelCustRecord").setVisible(false);
							that.getView().byId("deleteCustRecord").setVisible(true);
							this.onConditionTableSrvCall();
						}
					} else {
						that.getView().byId("createCustRecord").setText(that.rescrModel.getText("CreateCustomerRecord"));
						that.getView().byId("cancelCustRecord").setVisible(false);
						that.getView().byId("deleteCustRecord").setVisible(true);
						this.onConditionTableSrvCall();
						sap.m.MessageToast.show("Condition Record created successfully");
					}

				}.bind(this),
				error: function (oError) {
					sap.m.MessageToast.show(that.rescrModel.getText("Error"));
				}
			});

		},
		disableTableSelection: function () {
			var tableList = this.getView().byId("TableBox").getItems();
			for (var i = 0; i < tableList.length; i++) {
				tableList[i].setMode("None");
			}
		},
		onCloseErrorDialog: function () {
			if (!this.oErrorMsgsDailog) {
				this.oErrorMsgsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ErrorMessages", this);
			}
			this.oErrorMsgsDailog.close();
			this.onConditionTableSrvCall(this.customer, this.productVal, this.contractVal);
		},
		onAprvConflictBtnPress: function (evt) {
			var btnText = evt.getSource().getText();
			if (!this.oConflictRecordsDailog) {
				this.oConflictRecordsDailog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ConflictRecords", this);
			}
			this.oConflictRecordsDailog.close();
			if (btnText === "Yes") {
				this.onConfirmScreenSrvCall(this.allData);
			} else if (this.successRecords.length !== 0) {
				this.onConfirmScreenSrvCall(this.successRecords);
			}
		},
		onPress: function () {
			if (this.getView().byId("createCustRecord").getText() === this.rescrModel.getText("Confirm")) {
				this.getView().byId("cancelCustRecord").setVisible(false);
				this.getView().byId("deleteCustRecord").setVisible(true);
				this.onConditionTableSrvCall();
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("LandingPage");

			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
		 */
		// onBeforeRendering: function() {
		//
		// },

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
		 */
		// onAfterRendering: function() {
		//
		// },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZDS_CREATE_UPDATE_PRICE.viewApprovePriceDetail
		 */
		// onExit: function() {
		//
		// }

	});

});