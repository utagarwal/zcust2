sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessagePopoverItem",
	"sap/m/MessagePopover",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessagePopoverItem, MessagePopover, Fragment, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("ZDS_CREATE_UPDATE_PRICE.controller.LandingPage", {
		// Methods calls start from here
		// This method is called when the app is initialized
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("LandingPage").attachPatternMatched(this._onObjectMatched, this);
					this.rescrModel = this.getOwnerComponent().getModel("i18n").getResourceBundle();
					
					var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern: "MM.dd.yyyy"});
					var currDateObjDate = oDateFormat.format(new Date());	
					this.getView().byId("idDatePicker").setValue(currDateObjDate);
		},

		// This method is called when the navigation happens from Main view to S1 View
		_onObjectMatched: function (oEvent) {
			// this.getView().byId("idMainTab").setVisible(false);
		},

		// This method is called when the user presses GO button at the filter bar
		onFilterSearch: function (oEvent) {
			
			var filterDataObj = {};
        
			filterDataObj.action = this.getView().byId("ActionSelect").getSelectedKey();
			filterDataObj.productKey = this.getView().byId("idProductKey").getValue().toUpperCase();
				filterDataObj.customer = this.getView().byId("idCustomer").getValue().toUpperCase();
				filterDataObj.salesOrg = this.getView().byId("idSalesOrg").getValue().toUpperCase();
				filterDataObj.distChannel = this.getView().byId("idDistributionChannel").getValue();
				filterDataObj.materialGroup = this.getView().byId("idMaterialGroup").getValue().toUpperCase();
				filterDataObj.shipToCountry = this.getView().byId("idShipToCountry").getValue().toUpperCase();
				filterDataObj.intentOfUse = this.getView().byId("idIntentOfUse").getValue();
				filterDataObj.validOn = this.getView().byId("idDatePicker").getValue();
			if (filterDataObj.productKey === "" || filterDataObj.customer === "" || filterDataObj.materialGroup === "" || filterDataObj.validOn === "" || filterDataObj.validOn === null){
				sap.m.MessageToast.show(this.rescrModel.getText("MandtFieldsMsg"));
				return false;
			}
		/*	var oFilters = [];
			if (action !== "") {
				oFilters.push(new sap.ui.model.Filter("Scenario", sap.ui.model.FilterOperator.EQ, action));
			}
			if (productKey !== "") {
				oFilters.push(new sap.ui.model.Filter("ProductKey", sap.ui.model.FilterOperator.EQ, productKey));
			}
			if (salesOrg !== "") {
					oFilters.push(new sap.ui.model.Filter("SalesOrganization", sap.ui.model.FilterOperator.EQ, salesOrg));
			}
			if (customer !== "") {
					oFilters.push(new sap.ui.model.Filter("Customer", sap.ui.model.FilterOperator.EQ, customer));
			}
			if (distChannel !== "") {
					oFilters.push(new sap.ui.model.Filter("DistributionChannel", sap.ui.model.FilterOperator.EQ, distChannel));
			}
			if (materialGroup !== "") {
					oFilters.push(new sap.ui.model.Filter("MaterialGroup3", sap.ui.model.FilterOperator.EQ, materialGroup));
			}
			if (shipToCountry !== "") {
					oFilters.push(new sap.ui.model.Filter("ShipToCountry", sap.ui.model.FilterOperator.EQ, shipToCountry));
			}
			if (intentOfUse !== "") {
					oFilters.push(new sap.ui.model.Filter("IntentOfUse", sap.ui.model.FilterOperator.EQ, intentOfUse));
			}
			if (validOn !== "" || validOn !== null) {
					oFilters.push(new sap.ui.model.Filter("ValidOn", sap.ui.model.FilterOperator.EQ, validOn));
}
			var aFilters = new Filter({
				filters: oFilters,
				and: true
			});*/
			
				var aSelectionSet = oEvent.getParameter("selectionSet");
				var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
							if (oControl.getValue){
								if (oControl.getValue()) {
									aResult.push(new Filter({
										path: oControl.getName(),
										operator: FilterOperator.EQ,
										value1: oControl.getValue()
									}));
								}
						} else if (oControl.getSelectedKey()) {
							aResult.push(new Filter({
								path: oControl.getName(),
								operator: FilterOperator.Contains,
								value1: oControl.getSelectedKey()
							}));
						}

						return aResult;
					},
					[]);
			
			var oModelFilter = this.getView().getModel("FilterModel");
			var FilterData = {};
			FilterData.filterDataObj = filterDataObj;
			FilterData.aFilters = aFilters;
			oModelFilter.setData(FilterData);
			return true;
		},

		/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/
		onValueHelpProductKeyF4: function (oEvent) {

			this._oValueHelpProductKeyDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ProductKeyF4", this);
			this.getView().addDependent(this._oValueHelpProductKeyDialog);
			var oTable = this._oValueHelpProductKeyDialog.getTable();

			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("ProductKey"),
					template: "matnr"
				}, {
					label: this.rescrModel.getText("ProductKeyDesc"),
					template: "maktg"
				}]
			});
			this._oValueHelpProductKeyDialog.getTable().setModel(oColModel2, "columns");

			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/ProductKeyHelp");
			}
			this._oValueHelpDialog.setTokens(this.getView().byId("idProductKey").getTokens());
			this._oValueHelpProductKeyDialog.update();
			this._oValueHelpProductKeyDialog.open();
		},
		onValueHelpProductKeyF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idProductKey");
			oInput.setTokens(aTokens);
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4CancelPress: function () {
			this._oValueHelpProductKeyDialog.close();
		},
		onValueHelpProductKeyF4AfterClose: function () {
			this._oValueHelpProductKeyDialog.destroy();
		},

	/*	onSuggestionItemSelectedProductKey: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idProductKey").setValue(sDescription);
		},*/
		
			onSearchProductKeyF4: function (oEvent) {
		//	var sSearchQuery = this._oBasicSearchField.getValue(),
		//	var	aSelectionSet = oEvent.getParameter("selectionSet");
			var	aSelectionSet = oEvent.getParameter("selectionSet");
			var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
				if (oControl.getValue()) {
					aResult.push(new Filter({
						path: oControl.getName(),
						operator: FilterOperator.Contains,
						value1: oControl.getValue()
					}));
				}

				return aResult;
			}, []);

		/*	aFilters.push(new Filter({
				filters: [
					new Filter({
						path: "matnr",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					}),
					new Filter({
						path: "maktg",
						operator: FilterOperator.Contains,
						value1: sSearchQuery
					})
				],
				and: false
			}));*/

			this._filterProductKeyTable(new Filter({
				filters: aFilters,
				and: true
			}));
		},

		_filterProductKeyTable: function (oFilter) {

			 this._oValueHelpProductKeyDialog.getTableAsync().then(function (oTable) {
				if (oTable.bindRows) {
					oTable.getBinding("rows").filter(oFilter);
				}

				if (oTable.bindItems) {
					oTable.getBinding("items").filter(oFilter);
				}

				 this._oValueHelpProductKeyDialog.update();
			});
		},
		

/*		onSearchProductKeyF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpProductKeyDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'matnr',
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'maktg',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});
			oTable.getBinding("rows").filter(aFilters);
		},*/

		/*----------------------------------------Product Key F4 Start----------------------------------------------------------------*/

		/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/
		onValueHelpCustomer: function (oEvent) {

			this._oValueHelpCustomerDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.CustomerF4", this);
			this.getView().addDependent(this._oValueHelpCustomerDialog);
			var oTable = this._oValueHelpCustomerDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("Customer"),
					template: "Customer"
				}, {
					label: this.rescrModel.getText("CustomerNameText"),
					template: "CustomerName"
				}]
			});
			this._oValueHelpCustomerDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/CustomerHelp");
			}
			this._oValueHelpCustomerDialog.update();
			this._oValueHelpCustomerDialog.open();
		},
		onValueHelpCustomerF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idCustomer");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4CancelPress: function () {
			this._oValueHelpCustomerDialog.close();
		},
		onValueHelpCustomerF4AfterClose: function () {
			this._oValueHelpCustomerDialog.destroy();
		},

		onSuggestionItemSelectedCustomer: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idCustomer").setValue(sDescription);
		},

		onSearchCustomerF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpCustomerDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'Customer',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'CustomerName',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});

			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------Customer  F4 Start----------------------------------------------------------------*/

		/*----------------------------------------MaterialGroup  F4 Start----------------------------------------------------------------*/

		onValueHelpMaterialGroup: function (oEvent) {

			this._oValueHelpMaterialDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.MaterialGroupF4", this);
			this.getView().addDependent(this._oValueHelpMaterialDialog);
			var oTable = this._oValueHelpMaterialDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("AdditionalMaterialGroup"),  
					template: "AdditionalMaterialGroup3"
				}, {
					label: this.rescrModel.getText("AdditionalMaterialGroupText"),   
					template: "AdditionalMaterialGroup3_Text"
				}]
			});
			this._oValueHelpMaterialDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_AdditionalMaterialGroup3");
			}
			this._oValueHelpMaterialDialog.update();
			this._oValueHelpMaterialDialog.open();
		},
		onValueHelpMaterialGroupF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idMaterialGroup");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpMaterialDialog.close();
		},
		onValueHelpMaterialGroupF4CancelPress: function () {
			this._oValueHelpMaterialDialog.close();
		},
		onValueHelpMaterialGroupF4AfterClose: function () {
			this._oValueHelpMaterialDialog.destroy();
		},

		onSuggestionItemSelectedMaterialGroup: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idMaterialGroup").setValue(sDescription);
		},

		onSearchMaterialGroupF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpMaterialDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'AdditionalMaterialGroup3',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'AdditionalMaterialGroup3_Text',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});

			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------MaterialGroup  F4 End----------------------------------------------------------------*/

		/*----------------------------------------SalesOrg  F4 Start----------------------------------------------------------------*/
		onValueHelpSalesOrg: function (oEvent) {

			this._oValueHelpSalesOrgDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.SalesOrgF4", this);
			this.getView().addDependent(this._oValueHelpSalesOrgDialog);
			var oTable = this._oValueHelpSalesOrgDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label:this.rescrModel.getText("SalesOrganization"),   
					template: "SalesOrganization"
				}, {
					label: this.rescrModel.getText("SalesOrganizationText"),  
					template: "SalesOrganization_Text"
				}]
			});
			this._oValueHelpSalesOrgDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/C_SalesOrganizationVH");
			}
			this._oValueHelpSalesOrgDialog.update();
			this._oValueHelpSalesOrgDialog.open();
		},
		onValueHelpSalesOrgF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idSalesOrg");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4CancelPress: function () {
			this._oValueHelpSalesOrgDialog.close();
		},
		onValueHelpSalesOrgF4AfterClose: function () {
			this._oValueHelpSalesOrgDialog.destroy();
		},

		onSuggestionItemSelectedSalesOrg: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idSalesOrg").setValue(sDescription);
		},
		onSearchSalesOrgF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpSalesOrgDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'SalesOrganization',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'SalesOrganization_Text',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});

			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------SalesOrg  F4 End----------------------------------------------------------------*/

		/*----------------------------------------ShipToCountry  F4 Start----------------------------------------------------------------*/

		onValueHelpShipToCountry: function (oEvent) {

			this._oValueHelpShipToCountryDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.ShipToCountryF4", this);
			this.getView().addDependent(this._oValueHelpShipToCountryDialog);
			var oTable = this._oValueHelpShipToCountryDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("Country"),
					template: "Country"
				}, {
					label: this.rescrModel.getText("CountryText"), 
					template: "Country_Text"
				}]
			});
			this._oValueHelpShipToCountryDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/I_Country");
			}
			this._oValueHelpShipToCountryDialog.update();
			this._oValueHelpShipToCountryDialog.open();
		},
		onValueHelpShipToCountryF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idShipToCountry");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpShipToCountryF4CancelPress: function () {
			this._oValueHelpShipToCountryDialog.close();
		},
		onValueHelpShipToCountryF4AfterClose: function () {
			this._oValueHelpShipToCountryDialog.destroy();
		},
		onSuggestionItemSelectedShipToCountry: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idShipToCountry").setValue(sDescription);
		},

		onSearchShipToCountryF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpShipToCountryDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'Country',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'Country_Text',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});
			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------ShipToCountry  F4 End----------------------------------------------------------------*/

		/*----------------------------------------DistributionChannel  F4 Start----------------------------------------------------------------*/

		onValueHelpDistributionChannel: function (oEvent) {

			this._oValueHelpDistributionChannelDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.DistributionChannel", this);
			this.getView().addDependent(this._oValueHelpDistributionChannelDialog);
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("DistributionChannelDesc"),   
					template: "vtweg"
				}, {
					label: this.rescrModel.getText("DistributionChannelText"), 
					template: "vtext"
				}]
			});
			this._oValueHelpDistributionChannelDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/SHSM_H_MVKE");
			}
			this._oValueHelpDistributionChannelDialog.update();
			this._oValueHelpDistributionChannelDialog.open();
		},
		onValueHelpDistributionChannelF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idDistributionChannel");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4CancelPress: function () {
			this._oValueHelpDistributionChannelDialog.close();
		},
		onValueHelpDistributionChannelF4AfterClose: function () {
			this._oValueHelpDistributionChannelDialog.destroy();
		},
		onSuggestionItemSelectedDistributionChannel: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idDistributionChannel").setValue(sDescription);
		},
		onSearchDistributionChannelF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpDistributionChannelDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'vtweg',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'vtext',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});
			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------DistributionChannel  F4 End----------------------------------------------------------------*/

		/*----------------------------------------IntentOfUse  F4 Start----------------------------------------------------------------*/

		onValueHelpIntentOfUse: function (oEvent) {

			this._oValueHelpIntentOfUseDialog = sap.ui.xmlfragment("ZDS_CREATE_UPDATE_PRICE.view.fragment.IntentOfUse", this);
			this.getView().addDependent(this._oValueHelpIntentOfUseDialog);
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();
			var oColModel2 = new sap.ui.model.json.JSONModel();
			oColModel2.setData({
				cols: [{
					label: this.rescrModel.getText("IntentOfUseDesc"),   
					template: "IntentOfUse"
				}, {
					label: this.rescrModel.getText("UsageText"),     
					template: "UsageText"
				}]
			});
			this._oValueHelpIntentOfUseDialog.getTable().setModel(oColModel2, "columns");
			if (oTable.bindRows) {
				oTable.bindAggregation("rows", "/IntentOfUse");
			}
			this._oValueHelpIntentOfUseDialog.update();
			this._oValueHelpIntentOfUseDialog.open();
		},
		onValueHelpIntentOfUseF4OkPress: function (oEvent) {
			var aTokens = oEvent.getParameter("tokens");
			var oInput = this.getView().byId("idIntentOfUse");
			oInput.setValue(aTokens[0].getKey());
			oInput.setTooltip(aTokens[0].getText());
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4CancelPress: function () {
			this._oValueHelpIntentOfUseDialog.close();
		},
		onValueHelpIntentOfUseF4AfterClose: function () {
			this._oValueHelpIntentOfUseDialog.destroy();
		},
		onSuggestionItemSelectedIntentOfUse: function (oEvent) {
			var oItem = oEvent.getParameter("selectedItem");
			var sDescription = oItem.getKey();
			this.getView().byId("idIntentOfUse").setValue(sDescription);
		},
		onSearchIntentOfUseF4: function (oEvent) {
			var sVendorValue = oEvent.getParameters().newValue;
			var oTable = this._oValueHelpIntentOfUseDialog.getTable();
			var aFilters = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						path: 'IntentOfUse',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					}),
					new sap.ui.model.Filter({
						path: 'UsageText',
						operator: sap.ui.model.FilterOperator.EQ,
						value1: sVendorValue
					})
				],
				and: false
			});
			oTable.getBinding("rows").filter(aFilters);
		},

		/*----------------------------------------IntentOfUse  F4 End----------------------------------------------------------------*/

		toView2Press: function () {
			var mandtFlag = this.onFilterSearch();
			if (mandtFlag){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("PriceApproval");
			}
		}
	});
});